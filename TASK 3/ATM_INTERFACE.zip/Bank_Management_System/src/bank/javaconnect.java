/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sidas
 */
package bank;
import java.lang.*;
import javax.swing.JOptionPane;
public class javaconnect{
    public static void main(String args[]){
    Loading ld=new Loading();
    ld.setVisible(true);
    ld.progressbar.setMinimum(0); 
    try{
    for(int i=0;i<=100;i++){
        Thread.sleep(50);
        ld.progressbar.setValue(i);
        int n=ld.progressbar.getValue();
        if(n==100){
            Authentication at=new Authentication();
            at.setVisible(true);
            ld.dispose();
        }

    }
    }catch(Exception e){
        e.printStackTrace();
    }
    }
}


