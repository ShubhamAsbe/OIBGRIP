
package bank;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sidas
 */
public class MyPage extends javax.swing.JFrame {
Connection conn;
ResultSet rs;
PreparedStatement pat;
Statement st;
String MPID;
public String MPIN;
String dep;
String tran;
String with;
public String ACC;
public String Date;
String All_bal;
String All_amt;
String Ran="NULL";
int d_temp=0;
int w_temp=0;
int t_temp=0;

    /**
     * Creates new form MyPage
     */
  
     
    public MyPage() {
        initComponents();
       
        Table1();
        
    }
    
    public MyPage(String acc,String pin,String ID){
        initComponents();
        String acc_no=acc;
        String pin_code=pin;
        profile(acc_no,pin_code);
        deposit(acc_no);
        transfer(acc_no);
        withdrawl(acc_no);
        view_balance(acc_no);
        table11(acc_no);
        MPID=ID;
        MPIN=pin;
        ACC=acc;
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");  
        LocalDateTime now = LocalDateTime.now();  
        Date = dtf.format(now);
        datelbl.setText(Date);
        
    }

    
    public void Table1(){
        try{
        
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            }finally{
            try{
                
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }
    
           
    public void profile(String acc,String pin){
         try
        {

            String sql=("select * from account");
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
            st=conn.createStatement();
            rs=st.executeQuery(sql);
            
            while(rs.next()){
        String Acc=rs.getString("Acc");
        String Name=rs.getString("Name");
        String dob=rs.getString("DOB");
        String Pin=rs.getString("Pin");
        String Acc_Type=rs.getString("Acc_type");
        String Nationality=rs.getString("Nationality");
        String Caste=rs.getString("Caste");
        String MICR_No=rs.getString("MICR_No");
        String Gender=rs.getString("Gender");
        String Mob=rs.getString("Mobile");
        String Address=rs.getString("Address");
        String Sec_Q=rs.getString("Sec_Q");
        String Sec_A=rs.getString("Sec_A");
        String Balance=rs.getString("Balance");
        
        if(acc.equals(Acc) && pin.equals(Pin)){
        p_acc_no.setText(Acc);
        p_acc_type.setText(Acc_Type);
        p_address.setText(Address);
        p_name.setText(Name);
        p_caste.setText(Caste);
        p_mob_no.setText(Mob);
        p_nationality.setText(Nationality);
        p_seq_q.setText(Sec_Q);
        p_gender.setText(Gender);
        p_DOB.setText(dob);
  //      buttonGroup1.clearSelection();
            
        }
            }

        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e);
        }
    }
    
    public void deposit(String acc){
        try{
            String sql=("select * from account");
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
            st=conn.createStatement();
            rs=st.executeQuery(sql);
            
            while(rs.next()){
            String Acc=rs.getString("Acc");
            String Name=rs.getString("Name");
            String Balance=rs.getString("Balance");    
                
             if(acc.equals(Acc)){
             d_acc_no.setText(Acc);
             d_balance.setText(Balance);
             d_name.setText(Name);
            }
        }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }
    
        public void transfer(String acc){
        try{
            String sql=("select * from account");
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
            st=conn.createStatement();
            rs=st.executeQuery(sql);
            
            while(rs.next()){
            String Acc=rs.getString("Acc");
            String Name=rs.getString("Name");
            String Balance=rs.getString("Balance");    
                
             if(acc.equals(Acc)){
             t_acc_no.setText(Acc);
             t_balance.setText(Balance);
             t_name.setText(Name);
            }
        }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }
        
            public void withdrawl(String acc){
        try{
            String sql=("select * from account");
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
            st=conn.createStatement();
            rs=st.executeQuery(sql);
            
            while(rs.next()){
            String Acc=rs.getString("Acc");
            String Name=rs.getString("Name");
            String Balance=rs.getString("Balance");    
                
             if(acc.equals(Acc)){
             w_acc_no.setText(Acc);
             w_balance.setText(Balance);
             w_name.setText(Name);
            }
        }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }
            public void view_balance(String acc){
        try{
            String sql=("select * from account");
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
            st=conn.createStatement();
            rs=st.executeQuery(sql);
            
            while(rs.next()){
            String Acc=rs.getString("Acc");
            String Name=rs.getString("Name");
            String Balance=rs.getString("Balance");  
            String MICR_no=rs.getString("MICR_No");
            String mob=rs.getString("Mobile");
                
             if(acc.equals(Acc)){
             v_acc_no.setText(Acc);
             v_balance.setText(Balance);
             v_name.setText(Name);
             v_micr_no.setText(MICR_no);
             v_mob_no.setText(mob);
            }
        }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }    
        
            public void refresh(){
              
                int temp=0;
        String sql="select * from account";

        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
            st=conn.createStatement();//create statement of query line 155
            rs=st.executeQuery(sql);
          while(rs.next()){
                String accCheck=rs.getString("Acc");
                String bal=rs.getString("Balance");
                if(ACC.equals(accCheck)){
                    d_balance.setText(bal);
                    v_balance.setText(bal);
                    w_balance.setText(bal);
                    t_balance.setText(bal);
                    w_amt.setText("");
                    t_amt.setText("");
                    d_deposit.setText("");
                    d_total.setText("");
                    t_total.setText("");
                    w_total.setText("");
                    t_transfer_acc.setText("");                   
                }
          }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
                
        }
            
                public void table11(String acc_no){
                    
                    try
        {
            DefaultTableModel mt = (DefaultTableModel)table.getModel();
            while(mt.getRowCount() > 0)
            {
            mt.removeRow(0);
            }

            String sql=("select * from balances");
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
            st=conn.createStatement();
            rs=st.executeQuery(sql);
            DefaultTableModel tm = (DefaultTableModel)table.getModel();
            
            while(rs.next()){
        String date=rs.getString("Date");
        String acc=rs.getString("Acc_no");
        String acc_t=rs.getString("Acc_no_transfer");
        String dtw=rs.getString("D_T_W");
        String bal_b=rs.getString("Bal_before");
        String amt=rs.getString("Amount");
        String bal_a=rs.getString("Bal_after");
        
        if(acc.equals(acc_no)){
         Object O[]={rs.getString("Date"),rs.getString("Acc_no"),rs.getString("Acc_no_transfer"),rs.getString("D_T_W"),rs.getString("Bal_before"),rs.getString("Amount"),rs.getString("Bal_after")};
         tm.addRow(O);
            
        }
            }

        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this, e);
        }
                    
        }

                public void call_table(){
                    table11(ACC);
                }
            
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        p_name = new javax.swing.JTextField();
        p_DOB = new javax.swing.JTextField();
        p_nationality = new javax.swing.JTextField();
        p_gender = new javax.swing.JTextField();
        p_address = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        p_acc_no = new javax.swing.JTextField();
        p_acc_type = new javax.swing.JTextField();
        p_caste = new javax.swing.JTextField();
        p_mob_no = new javax.swing.JTextField();
        p_seq_q = new javax.swing.JTextField();
        edit = new javax.swing.JButton();
        Save = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        d_name = new javax.swing.JTextField();
        d_acc_no = new javax.swing.JTextField();
        d_balance = new javax.swing.JTextField();
        d_deposit = new javax.swing.JTextField();
        deposit = new javax.swing.JButton();
        d_total = new javax.swing.JTextField();
        total_d = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        t_name = new javax.swing.JTextField();
        t_acc_no = new javax.swing.JTextField();
        t_balance = new javax.swing.JTextField();
        t_amt = new javax.swing.JTextField();
        t_total = new javax.swing.JTextField();
        total_t = new javax.swing.JButton();
        t_transfer = new javax.swing.JButton();
        jLabel34 = new javax.swing.JLabel();
        t_transfer_acc = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        w_name = new javax.swing.JTextField();
        w_acc_no = new javax.swing.JTextField();
        w_balance = new javax.swing.JTextField();
        w_amt = new javax.swing.JTextField();
        w_total = new javax.swing.JTextField();
        total_w = new javax.swing.JButton();
        w_withdraw = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        v_name = new javax.swing.JTextField();
        v_acc_no = new javax.swing.JTextField();
        v_micr_no = new javax.swing.JTextField();
        v_mob_no = new javax.swing.JTextField();
        v_balance = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        c_old_pin = new javax.swing.JTextField();
        c_new_pin = new javax.swing.JTextField();
        c_change = new javax.swing.JButton();
        c_clear = new javax.swing.JButton();
        c_confirm_pin = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        logout = new javax.swing.JButton();
        datelbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 0));
        jLabel1.setText("SBANKING");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Date:");

        jTabbedPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jTabbedPane1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 102, 0)));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Name:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Date of Birth:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Nationality:");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("Gender:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setText("Address:");

        p_name.setEditable(false);
        p_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_nameActionPerformed(evt);
            }
        });

        p_DOB.setEditable(false);

        p_nationality.setEditable(false);

        p_gender.setEditable(false);

        p_address.setEditable(false);

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Account No.:");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setText("Account Type:");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setText("Caste:");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel12.setText("Mobile:");

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setText("Security Q:");

        p_acc_no.setEditable(false);

        p_acc_type.setEditable(false);

        p_caste.setEditable(false);
        p_caste.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_casteActionPerformed(evt);
            }
        });

        p_mob_no.setEditable(false);

        p_seq_q.setEditable(false);

        edit.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        edit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/edit-icon.png"))); // NOI18N
        edit.setText("Edit");
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });

        Save.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        Save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Programming-Save-As-icon.png"))); // NOI18N
        Save.setText("Save");
        Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(49, 49, 49)
                                .addComponent(p_name))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel7))
                                .addGap(37, 37, 37)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(p_gender, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_address, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(p_nationality, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p_DOB, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel6))))
                .addGap(75, 75, 75)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13)
                    .addComponent(jLabel10))
                .addGap(59, 59, 59)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(p_acc_type, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(edit)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                            .addComponent(Save))
                        .addComponent(p_seq_q, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                        .addComponent(p_mob_no, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(p_caste, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(p_acc_no, javax.swing.GroupLayout.Alignment.LEADING)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(p_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel9)
                    .addComponent(p_acc_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(p_DOB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(p_acc_type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 87, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(p_nationality, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(p_caste, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(71, 71, 71)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(p_gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(p_mob_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(59, 59, 59)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(p_address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(p_seq_q, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(edit)
                    .addComponent(Save))
                .addGap(78, 78, 78))
        );

        jTabbedPane1.addTab("Profile", jPanel1);

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel15.setText("Name:");

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel16.setText("Account No.:");

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel17.setText("Available Balance:");

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel18.setText("Deposit Amount:");

        d_name.setEditable(false);

        d_acc_no.setEditable(false);

        d_balance.setEditable(false);
        d_balance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                d_balanceActionPerformed(evt);
            }
        });

        d_deposit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                d_depositActionPerformed(evt);
            }
        });

        deposit.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        deposit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bank/Button-Add-icon.png"))); // NOI18N
        deposit.setText("Deposit");
        deposit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                depositActionPerformed(evt);
            }
        });

        d_total.setEditable(false);

        total_d.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        total_d.setText("Total");
        total_d.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                total_dActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel16)
                            .addComponent(jLabel15))
                        .addGap(40, 40, 40))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel18)
                            .addComponent(jLabel17))
                        .addGap(18, 18, 18)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(d_name)
                    .addComponent(d_acc_no)
                    .addComponent(d_balance)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(d_deposit, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(d_total, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)))
                .addGap(33, 33, 33)
                .addComponent(total_d)
                .addGap(188, 188, 188))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(253, 253, 253)
                .addComponent(deposit)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_acc_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_balance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_deposit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18)
                    .addComponent(d_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(total_d))
                .addGap(27, 27, 27)
                .addComponent(deposit)
                .addContainerGap(292, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Deposit", jPanel2);

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 204)));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel14.setText("Name:");

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel19.setText("Account No.:");

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel20.setText("Available Balance:");

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel21.setText("Transfer Amount:");

        t_name.setEditable(false);

        t_acc_no.setEditable(false);
        t_acc_no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_acc_noActionPerformed(evt);
            }
        });

        t_balance.setEditable(false);

        t_total.setEditable(false);

        total_t.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        total_t.setText("Total");
        total_t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                total_tActionPerformed(evt);
            }
        });

        t_transfer.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        t_transfer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bank/Ok-icon.png"))); // NOI18N
        t_transfer.setText("Transfer");
        t_transfer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_transferActionPerformed(evt);
            }
        });

        jLabel34.setText("Transfer to(Acc_No.):");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel20)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel34)
                                    .addComponent(jLabel21))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(t_name)
                                    .addComponent(t_acc_no)
                                    .addComponent(t_balance, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
                                    .addComponent(t_transfer_acc)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(t_amt, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(t_total, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(37, 37, 37)
                                .addComponent(total_t))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(271, 271, 271)
                        .addComponent(t_transfer)))
                .addContainerGap(157, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(t_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(t_acc_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(t_balance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(t_transfer_acc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(t_amt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(t_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(total_t))
                .addGap(38, 38, 38)
                .addComponent(t_transfer)
                .addContainerGap(201, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Transfer", jPanel3);

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel22.setText("Name:");

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel23.setText("Account No.:");

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel24.setText("Available Balance:");

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel25.setText("Amount:");

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel26.setText("Total:");

        w_name.setEditable(false);
        w_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                w_nameActionPerformed(evt);
            }
        });

        w_acc_no.setEditable(false);

        w_balance.setEditable(false);

        w_total.setEditable(false);

        total_w.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        total_w.setText("Total");
        total_w.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                total_wActionPerformed(evt);
            }
        });

        w_withdraw.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        w_withdraw.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bank/Minus-icon.png"))); // NOI18N
        w_withdraw.setText("Withdraw");
        w_withdraw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                w_withdrawActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel24)
                                    .addComponent(jLabel23)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel26))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(w_name, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                                    .addComponent(w_acc_no)
                                    .addComponent(w_balance)
                                    .addComponent(w_amt)
                                    .addComponent(w_total))
                                .addGap(31, 31, 31)
                                .addComponent(total_w))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(237, 237, 237)
                        .addComponent(w_withdraw)))
                .addContainerGap(226, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22)
                    .addComponent(w_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(w_acc_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(w_balance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(w_amt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(w_total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(total_w))
                .addGap(28, 28, 28)
                .addComponent(w_withdraw)
                .addContainerGap(215, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Withdrawl", jPanel4);

        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 51)));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "DATE", "ACC_NO", "ACC_NO (Transer to)", "Deposit/Transfer/Withdrawl", "BALANCE(Before)", "AMOUNT", "BALANCE(After)"
            }
        ));
        table.setEnabled(false);
        jScrollPane1.setViewportView(table);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 679, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 516, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Transaction", jPanel6);

        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 153)));

        jLabel27.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel27.setText("Name:");

        jLabel28.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel28.setText("Account No.:");

        jLabel29.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel29.setText("MICR No.:");

        jLabel30.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel30.setText("Balance:");

        jLabel31.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel31.setText("Mobile No.:");

        v_name.setEditable(false);

        v_acc_no.setEditable(false);
        v_acc_no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                v_acc_noActionPerformed(evt);
            }
        });

        v_micr_no.setEditable(false);
        v_micr_no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                v_micr_noActionPerformed(evt);
            }
        });

        v_mob_no.setEditable(false);

        v_balance.setEditable(false);
        v_balance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                v_balanceActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel28)
                    .addComponent(jLabel27)
                    .addComponent(jLabel29)
                    .addComponent(jLabel31)
                    .addComponent(jLabel30))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(v_balance, javax.swing.GroupLayout.DEFAULT_SIZE, 147, Short.MAX_VALUE)
                    .addComponent(v_mob_no)
                    .addComponent(v_micr_no)
                    .addComponent(v_acc_no)
                    .addComponent(v_name))
                .addContainerGap(285, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(v_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(v_acc_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(v_micr_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(v_mob_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(v_balance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(258, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("View Balance", jPanel7);

        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 255)));

        jLabel32.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel32.setText("Old PIN:");

        jLabel33.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel33.setText("New PIN:");

        c_change.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        c_change.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bank/change-password-icon.png"))); // NOI18N
        c_change.setText("Change");
        c_change.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_changeActionPerformed(evt);
            }
        });

        c_clear.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        c_clear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bank/Save-as-icon.png"))); // NOI18N
        c_clear.setText("Clear");
        c_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_clearActionPerformed(evt);
            }
        });

        jLabel41.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel41.setText("Confirm PIN:");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(159, 159, 159)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel33)
                    .addComponent(jLabel41)
                    .addComponent(jLabel32))
                .addGap(24, 24, 24)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(c_old_pin, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(c_change)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(c_clear))
                    .addComponent(c_new_pin)
                    .addComponent(c_confirm_pin))
                .addGap(214, 214, 214))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(c_old_pin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel33)
                    .addComponent(c_new_pin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c_confirm_pin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41))
                .addGap(42, 42, 42)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c_change)
                    .addComponent(c_clear))
                .addContainerGap(240, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Change pin", jPanel8);

        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bank/bank-icon.png"))); // NOI18N

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3), "CONTACT US", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 36))); // NOI18N

        jLabel35.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel35.setText("Email :");

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2), "ADVANCED JAVA PROJECT", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 0, 18))); // NOI18N

        jLabel40.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel40.setText("Shubham Asbe");

        jLabel43.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel43.setText("Meghraj Patil Sir");

        jLabel39.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel39.setText("System Developed By:");

        jLabel42.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel42.setText("Course Co-ordinator:");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(jLabel40))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel42)
                            .addComponent(jLabel39)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(jLabel43)))
                .addContainerGap(85, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel39)
                .addGap(3, 3, 3)
                .addComponent(jLabel40)
                .addGap(26, 26, 26)
                .addComponent(jLabel42)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel43)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        jLabel37.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel37.setText("Mobile No. :");

        jLabel38.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel38.setText("8698816985");

        jLabel36.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel36.setText("asbeshubham143@gmail.com");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel37)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel38))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel35)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel36)))
                .addGap(22, 22, 22))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(jLabel36))
                .addGap(39, 39, 39)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(jLabel38))
                .addGap(34, 34, 34)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(160, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Contact Us", jPanel9);

        logout.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bank/logout-icon.png"))); // NOI18N
        logout.setText("LOGOUT");
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });

        datelbl.setText("--");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 690, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(25, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)
                            .addComponent(datelbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(77, 77, 77))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(datelbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(logout))
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(751, 717));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void w_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_w_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_w_nameActionPerformed

    private void total_tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_total_tActionPerformed
        // TODO add your handling code here:
        try{
        int b_amt=Integer.parseInt(t_amt.getText());
        if(b_amt>=0){
        int amt=Integer.parseInt(t_balance.getText());
        if(amt>=b_amt){
        int a_amt=amt-b_amt;
        String s_amt=String.valueOf(a_amt);
        t_total.setText(s_amt);
        tran=s_amt;
        All_bal=String.valueOf(amt);
        All_amt=String.valueOf(b_amt);
        t_temp=1;
        }else{
            JOptionPane.showMessageDialog(this,"INSUFFICIENT BALANCE");
        }
        }else{
            JOptionPane.showMessageDialog(this,"INVALID AMOUNT");
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }//GEN-LAST:event_total_tActionPerformed

    private void t_acc_noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_acc_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t_acc_noActionPerformed

    private void d_depositActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_d_depositActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_d_depositActionPerformed

    private void d_balanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_d_balanceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_d_balanceActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
        p_address.setEditable(true);
        p_mob_no.setEditable(true);
    }//GEN-LAST:event_editActionPerformed

    private void p_casteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_casteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_casteActionPerformed

    private void p_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_nameActionPerformed

    private void v_acc_noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_v_acc_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_v_acc_noActionPerformed

    private void v_micr_noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_v_micr_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_v_micr_noActionPerformed

    private void c_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_clearActionPerformed
        // TODO add your handling code here:
        c_old_pin.setText("");
        c_new_pin.setText("");
        c_confirm_pin.setText("");
    }//GEN-LAST:event_c_clearActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        Authentication at=new Authentication();
        at.setVisible(true);
    }//GEN-LAST:event_logoutActionPerformed

    private void total_dActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_total_dActionPerformed
        // TODO add your handling code here:
        try{
        int b_amt=Integer.parseInt(d_deposit.getText());
        if(b_amt>=0){
            if(b_amt<=500000){
        int amt=Integer.parseInt(d_balance.getText());
        int a_amt=amt+b_amt;
        String s_amt=String.valueOf(a_amt);
        d_total.setText(s_amt);
        dep=s_amt;
        All_bal=String.valueOf(amt);
        All_amt=String.valueOf(b_amt);
        d_temp=1;
        }else{
           JOptionPane.showMessageDialog(this,"PLEASE ENTER THE DEPOSIT AMOUNT LESS THAN 500000(5 LAKH)");
        }
        }else{
            JOptionPane.showMessageDialog(this,"INVALID AMOUNT");
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }//GEN-LAST:event_total_dActionPerformed

    private void total_wActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_total_wActionPerformed
        // TODO add your handling code here:
        try{
        int b_amt=Integer.parseInt(w_amt.getText());
        if(b_amt>=0){
        int amt=Integer.parseInt(w_balance.getText());
        if(amt>=b_amt){
        int a_amt=amt-b_amt;
        String s_amt=String.valueOf(a_amt);
        w_total.setText(s_amt);
        with=s_amt;
        All_bal=String.valueOf(amt);
        All_amt=String.valueOf(b_amt);
        w_temp=1;
        }else{
            JOptionPane.showMessageDialog(this,"INSUFFICIENT BALANCE");
        }
        }else{
            JOptionPane.showMessageDialog(this,"INVALID AMOUNT");
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
    }//GEN-LAST:event_total_wActionPerformed

    private void c_changeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_changeActionPerformed
        // TODO add your handling code here:
        
        try
        {
            String n_pin = c_new_pin.getText();
            String o_pin = c_old_pin.getText();
            String c_pin= c_confirm_pin.getText();
            if(o_pin.equals(MPIN)){ 
                if(c_pin.equals(n_pin)){
             Class.forName("com.mysql.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
             String sql1=("UPDATE account SET Pin='"+n_pin+"' Where id ="+MPID);
             pat=conn.prepareStatement(sql1);
             pat.executeUpdate(sql1);
             Authentication at=new Authentication();
             at.setVisible(true);
             this.dispose();
             JOptionPane.showMessageDialog(this, "Success");
                  }else{
                    JOptionPane.showMessageDialog(this,"NEW PASSWORD DON'T MATCH WITH CONFIRM PASSWORD");
               }
            }else{
                JOptionPane.showMessageDialog(this,"OLD PASSWORD DON'T MATCH");
            }
                
       }
       catch(Exception e)
       {
            JOptionPane.showMessageDialog(this, e);
       }
    }//GEN-LAST:event_c_changeActionPerformed

    private void depositActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_depositActionPerformed
        // TODO add your handling code here:
        String Dep="Deposit";
        if(d_temp==1){
        try{
        Class.forName("com.mysql.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
             String sql1=("UPDATE account SET Balance='"+dep+"' Where id ="+MPID);
             pat=conn.prepareStatement(sql1);
             pat.executeUpdate(sql1);
             d_temp=0;
             
             st=conn.createStatement();
             String sql12=("Insert into balances(Date,Acc_no,Acc_no_transfer,D_T_W,Bal_before,Amount,Bal_after) Values('"+Date+"','"+ACC+"','"+Ran+"','"+Dep+"','"+All_bal+"','"+All_amt+"','"+dep+"')"); 
             st.executeUpdate(sql12);
             refresh();
             call_table();
             JOptionPane.showMessageDialog(this, "Success");
       
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"ERROR");
        }
        }else{
            JOptionPane.showMessageDialog(this, "CLICK THE TOTAL BUTTON FIRST");
        }
    }//GEN-LAST:event_depositActionPerformed

    private void t_transferActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_transferActionPerformed
        // TODO add your handling code here:
        String T_acc=t_transfer_acc.getText();
        
        if(T_acc.equals(ACC)){
            
            JOptionPane.showMessageDialog(this,"YOU CAN'T TRANSFER TO YOUR SELF");
        
        }else{
        int temp=0;
        String sql="select * from account";
        String accCheck=null;
        if(t_temp==1){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
            st=conn.createStatement();//create statement of query line 155
            rs=st.executeQuery(sql);
          while(rs.next()){
                accCheck=rs.getString("Acc");
                String IDCheck=rs.getString("ID");
                String bal=rs.getString("Balance");
                if(T_acc.equals(accCheck)){
                    int b_amt=Integer.parseInt(bal);
                    int amt=Integer.parseInt(t_amt.getText());
                    int a_amt=amt+b_amt;
                    t_temp=0;
                    String s_amt=String.valueOf(a_amt);
                    
             Class.forName("com.mysql.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
             String sql1=("UPDATE account SET Balance='"+s_amt+"' Where id ="+IDCheck);
             pat=conn.prepareStatement(sql1);
             pat.executeUpdate(sql1);
             
             st=conn.createStatement();
                 String sql3=("Insert into balances(Date,Acc_no,Acc_no_transfer,D_T_W,Bal_before,Amount,Bal_after) Values('"+Date+"','"+ACC+"','"+T_acc+"','"+"Transfer"+"','"+All_bal+"','"+All_amt+"','"+tran+"')");
                 st.executeUpdate(sql3);
 
                 call_table();
                 refresh();
             JOptionPane.showMessageDialog(this, "Success");
                    temp=1;
                    
                }
          }
          if(ACC.equals(ACC)){
          Class.forName("com.mysql.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
             String sql1=("UPDATE account SET Balance='"+tran+"' Where id ="+MPID);
             pat=conn.prepareStatement(sql1);
             pat.executeUpdate(sql1);
                 call_table();
                 refresh();
          }
          
        if(temp==0){
            JOptionPane.showMessageDialog(this,"Account Number is INVALID");
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }
        }else{
            JOptionPane.showMessageDialog(this, "CLICK THE TOTAL BUTTON FIRST");
        }
        }
    }//GEN-LAST:event_t_transferActionPerformed

    private void w_withdrawActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_w_withdrawActionPerformed
        // TODO add your handling code here:
        if(w_temp==1){
        try{
        Class.forName("com.mysql.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
             String sql1=("UPDATE account SET Balance='"+with+"' Where id ="+MPID);
             pat=conn.prepareStatement(sql1);
             pat.executeUpdate(sql1);
             
             st=conn.createStatement();
                 String sql=("Insert into balances(Date,Acc_no,Acc_no_transfer,D_T_W,Bal_before,Amount,Bal_after) Values('"+Date+"','"+ACC+"','"+Ran+"','"+"Withdrawl"+"','"+All_bal+"','"+All_amt+"','"+with+"')");
                 st.executeUpdate(sql);
             
                 call_table();
                 refresh();
             JOptionPane.showMessageDialog(this, "Success");
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"ERROR");
        }
        }else{
            JOptionPane.showMessageDialog(this, "CLICK THE TOTAL BUTTON FIRST");
        }
    }//GEN-LAST:event_w_withdrawActionPerformed

    private void SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveActionPerformed
        // TODO add your handling code here:
        String mob=p_mob_no.getText();
        String add=p_address.getText();
        double mobile=Double.parseDouble(mob);
         try{
             if(mobile > 999999999){
                
        Class.forName("com.mysql.jdbc.Driver");
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank?serverTimezone=UTC","root","");
             String sql1=("UPDATE account SET Mobile='"+mob+"' Where id ="+MPID);
             pat=conn.prepareStatement(sql1);
             pat.executeUpdate(sql1);
             String sql2=("UPDATE account SET Address='"+add+"' Where id ="+MPID);
             pat=conn.prepareStatement(sql2);
             pat.executeUpdate(sql2);
             JOptionPane.showMessageDialog(this, "Success");
             p_address.setEditable(false);
             p_mob_no.setEditable(false);
             }
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"ERROR");
        }
    }//GEN-LAST:event_SaveActionPerformed

    private void v_balanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_v_balanceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_v_balanceActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MyPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MyPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MyPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MyPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MyPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Save;
    private javax.swing.JButton c_change;
    private javax.swing.JButton c_clear;
    private javax.swing.JTextField c_confirm_pin;
    private javax.swing.JTextField c_new_pin;
    private javax.swing.JTextField c_old_pin;
    private javax.swing.JTextField d_acc_no;
    private javax.swing.JTextField d_balance;
    private javax.swing.JTextField d_deposit;
    private javax.swing.JTextField d_name;
    private javax.swing.JTextField d_total;
    private javax.swing.JLabel datelbl;
    private javax.swing.JButton deposit;
    private javax.swing.JButton edit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JButton logout;
    private javax.swing.JTextField p_DOB;
    private javax.swing.JTextField p_acc_no;
    private javax.swing.JTextField p_acc_type;
    private javax.swing.JTextField p_address;
    private javax.swing.JTextField p_caste;
    private javax.swing.JTextField p_gender;
    private javax.swing.JTextField p_mob_no;
    private javax.swing.JTextField p_name;
    private javax.swing.JTextField p_nationality;
    private javax.swing.JTextField p_seq_q;
    private javax.swing.JTextField t_acc_no;
    private javax.swing.JTextField t_amt;
    private javax.swing.JTextField t_balance;
    private javax.swing.JTextField t_name;
    private javax.swing.JTextField t_total;
    private javax.swing.JButton t_transfer;
    private javax.swing.JTextField t_transfer_acc;
    private javax.swing.JTable table;
    private javax.swing.JButton total_d;
    private javax.swing.JButton total_t;
    private javax.swing.JButton total_w;
    private javax.swing.JTextField v_acc_no;
    private javax.swing.JTextField v_balance;
    private javax.swing.JTextField v_micr_no;
    private javax.swing.JTextField v_mob_no;
    private javax.swing.JTextField v_name;
    private javax.swing.JTextField w_acc_no;
    private javax.swing.JTextField w_amt;
    private javax.swing.JTextField w_balance;
    private javax.swing.JTextField w_name;
    private javax.swing.JTextField w_total;
    private javax.swing.JButton w_withdraw;
    // End of variables declaration//GEN-END:variables
}
